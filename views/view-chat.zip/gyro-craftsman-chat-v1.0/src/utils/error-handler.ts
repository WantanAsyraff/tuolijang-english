import { AuthError, RequestError } from "@/types/error";
import { Message } from "@/utils/message";

export const handleError = (error: any) => {
  if (error instanceof AuthError) {
    Message.error(error.message);
  } else if (error instanceof RequestError) {
    Message.error(error.message);
  } else {
    Message.error("内部错误");
  }
};
