import { getCmsApi, getCmsKeyApi } from "@/api/user";
import { handleError } from "@/utils/error-handler";
import { Message } from "@/utils/message";

const CODE_TIP_DEFAULT = "获取验证码";

/**
 * 获取验证码
 */
export const useVerifyCode = () => {
  const codeTips = ref(CODE_TIP_DEFAULT);
  const isAllowGetVerifyCode = ref(true);
  const codeKey = ref("");

  const startTimer = () => {
    let time = 60;
    const timer = setInterval(() => {
      codeTips.value = `${time}s`;
      time--;
    }, 1000);
    setTimeout(() => {
      clearInterval(timer);
      codeTips.value = CODE_TIP_DEFAULT;
      isAllowGetVerifyCode.value = true;
    }, 60000);
  };

  const getVerifyCode = async (phone: string) => {
    if (!isAllowGetVerifyCode.value) return;
    isAllowGetVerifyCode.value = false;
    try {
      const smsCodeKeyRes = await getCmsKeyApi();
      codeKey.value = smsCodeKeyRes.data.key;
      const params = {
        phone,
        key: codeKey.value,
        from: 1,
        types: 0
      };
      await getCmsApi(params);
      Message.success("验证码发送成功");
      startTimer();
    } catch (error: any) {
      handleError(error);
      isAllowGetVerifyCode.value = true;
    }
  };

  return {
    codeTips,
    isAllowGetVerifyCode,
    codeKey,
    getVerifyCode
  };
};
