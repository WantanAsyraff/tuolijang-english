<template>
  <div class="px-16px pb-30px flex items-center mt-auto">
    <template v-if="isLogin && userInfo">
      <img :src="userInfo.avatar" class="w-32px h-32px rounded-full mr-8px" />
      <span class="flex-1 single-line">{{ userInfo.name }}</span>
      <i class="ai-icon ai-icon-tuichudenglu text-20px cursor-pointer text-#606266" @click="handleLogout" />
    </template>
    <template v-else>
      <img src="@/assets/icons/user-icon.png" class="w-32px h-32px rounded-full mr-8px" />
      <button @click="handleOpenLogin" class="hover:primary-color">登录</button>
    </template>
  </div>
</template>

<script setup lang="ts">
import { useUserStore } from "@/pinia/stores/useUserStore";
import { useRootStore } from "@/pinia/stores/useRootStore";
import { storeToRefs } from "pinia";
import { useRouter } from "vue-router";
import { ROUTE_KEY } from "@/constants/route-key";
import { useLoginDialogStore } from "@/pinia/stores/ui/useLoginDialogStore";

const userStore = useUserStore();
const router = useRouter();
const rootStore = useRootStore();
const { userInfo, isLogin } = storeToRefs(userStore);

const loginDialogStore = useLoginDialogStore();

const handleOpenLogin = () => {
  loginDialogStore.handleSetLoginDialogOpen();
};

const handleLogout = async () => {
  try {
    await ElMessageBox.confirm("确定要退出登录吗？", "提示", {
      confirmButtonText: "确定",
      cancelButtonText: "取消",
      type: "warning"
    });
    rootStore.reset();
    router.push({ name: ROUTE_KEY.CHAT_INDEX });
  } catch { }
};
</script>

<style lang="scss">

</style>
